"""
Enhanced Message System
Integrates Priority Queue, Batch Queue, and Retry Queue for comprehensive message handling
"""

import time
from typing import Dict, List, Optional
from models.priority_queue import PriorityMessageQueue
from models.batch_queue import BatchQueue
from models.retry_queue import RetryQueue


class EnhancedMessageSystem:
    """
    Enhanced message system that combines:
    - Priority Queue (existing): Handles message prioritization
    - Batch Queue (your implementation): Groups messages for network efficiency  
    - Retry Queue (your implementation): Handles failed delivery attempts
    """

    def __init__(self, 
                 max_history_size: int = 1000,
                 min_batch_size: int = 5,
                 max_batch_size: int = 50,
                 batch_timeout: float = 2.0,
                 max_retries: int = 5):
        """
        Initialize the enhanced message system

        Args:
            max_history_size: Max messages in circular history
            min_batch_size: Minimum messages before sending batch
            max_batch_size: Maximum messages per batch
            batch_timeout: Max time to wait before sending partial batch
            max_retries: Maximum retry attempts for failed messages
        """
        # Initialize core components
        self.priority_queue = PriorityMessageQueue(max_history_size)
        self.batch_queue = BatchQueue(
            min_batch_size=min_batch_size,
            max_batch_size=max_batch_size,
            timeout_seconds=batch_timeout,
            send_callback=self._handle_batch_send
        )
        self.retry_queue = RetryQueue(
            max_retries=max_retries,
            retry_callback=self._handle_retry_attempt
        )

        # System statistics
        self.system_stats = {
            'total_messages_processed': 0,
            'successful_deliveries': 0,
            'failed_deliveries': 0,
            'messages_in_retry': 0,
            'system_uptime': time.time()
        }

        print("Enhanced Message System initialized with Priority, Batch, and Retry queues")

    def add_message(self, message: str, user: str = "Anonymous", 
                   manual_priority: Optional[int] = None) -> Dict:
        """
        Add a message to the system (goes through all processing stages)

        Args:
            message: The message text
            user: Username of sender  
            manual_priority: Override auto-detection (1-4, None for auto)

        Returns:
            Dict containing the created message object
        """
        # Step 1: Add to priority queue (existing functionality)
        message_obj = self.priority_queue.add_message(message, user, manual_priority)
        
        # Step 2: Add to batch queue for efficient transmission
        self.batch_queue.enqueue(message_obj)
        
        # Update system stats
        self.system_stats['total_messages_processed'] += 1
        
        return message_obj

    def _handle_batch_send(self, batch: List[Dict], batch_size: int, trigger: str):
        """
        Handle sending a batch of messages (callback from BatchQueue)
        
        Args:
            batch: List of message objects to send
            batch_size: Number of messages in batch
            trigger: What triggered the batch send
        """
        print(f"Network transmission: Sending batch of {batch_size} messages ({trigger})")
        
        # Simulate network transmission (replace with actual network code)
        success = self._simulate_network_send(batch)
        
        if success:
            self.system_stats['successful_deliveries'] += batch_size
            print(f"✅ Batch transmission successful ({batch_size} messages)")
        else:
            # Add failed messages to retry queue
            for message_obj in batch:
                self.retry_queue.enqueue(message_obj, f"Batch transmission failed ({trigger})")
            
            self.system_stats['failed_deliveries'] += batch_size
            self.system_stats['messages_in_retry'] += batch_size
            print(f"❌ Batch transmission failed, {batch_size} messages added to retry queue")

    def _handle_retry_attempt(self, message: Dict, attempt_number: int) -> bool:
        """
        Handle retrying a failed message (callback from RetryQueue)
        
        Args:
            message: Message object to retry
            attempt_number: Current attempt number
            
        Returns:
            True if retry succeeded, False if failed
        """
        print(f"🔄 Retry attempt #{attempt_number} for message from {message['user']}")
        
        # Simulate retry transmission
        success = self._simulate_network_send([message])
        
        if success:
            self.system_stats['successful_deliveries'] += 1
            self.system_stats['messages_in_retry'] -= 1
            print(f"✅ Retry successful on attempt #{attempt_number}")
        else:
            print(f"❌ Retry attempt #{attempt_number} failed")
        
        return success

    def _simulate_network_send(self, messages: List[Dict]) -> bool:
        """
        Simulate network transmission (replace with your actual network code)
        
        Args:
            messages: List of messages to send
            
        Returns:
            True if transmission succeeded, False if failed
        """
        import random
        
        # Simulate 90% success rate for demonstration
        # In real implementation, this would be your actual network/websocket send
        success_rate = 0.9
        
        # Higher priority messages have better success rates
        if messages and messages[0]['priority'] <= 2:  # URGENT or HIGH
            success_rate = 0.95
        
        return random.random() < success_rate

    def get_next_message(self) -> Optional[Dict]:
        """
        Get the next highest priority message (delegates to priority queue)
        
        Returns:
            Message object with highest priority, or None if queue empty
        """
        return self.priority_queue.get_next_message()

    def get_history(self) -> List[Dict]:
        """
        Get message history (delegates to priority queue)
        
        Returns:
            List of message objects in chronological order
        """
        return self.priority_queue.get_history()

    def force_send_pending_batches(self) -> int:
        """
        Force send any pending batches immediately
        
        Returns:
            Number of messages in batches that were sent
        """
        return self.batch_queue.force_send_batch()

    def retry_failed_messages(self) -> int:
        """
        Force retry all failed messages immediately
        
        Returns:
            Number of messages marked for immediate retry
        """
        return self.retry_queue.force_retry_all()

    def get_comprehensive_stats(self) -> Dict:
        """
        Get comprehensive statistics from all system components
        
        Returns:
            Dictionary with detailed system statistics
        """
        # Get stats from each component
        priority_stats = self.priority_queue.get_queue_stats()
        batch_stats = self.batch_queue.get_stats()
        retry_stats = self.retry_queue.get_stats()
        
        # Calculate system uptime
        uptime_seconds = time.time() - self.system_stats['system_uptime']
        
        return {
            'system_overview': {
                **self.system_stats,
                'uptime_seconds': round(uptime_seconds, 2),
                'uptime_formatted': self._format_uptime(uptime_seconds),
                'overall_success_rate': self._calculate_success_rate()
            },
            'priority_queue': priority_stats,
            'batch_queue': batch_stats,
            'retry_queue': retry_stats
        }

    def _calculate_success_rate(self) -> float:
        """Calculate overall system success rate"""
        total_attempts = self.system_stats['successful_deliveries'] + self.system_stats['failed_deliveries']
        if total_attempts == 0:
            return 100.0
        return round((self.system_stats['successful_deliveries'] / total_attempts) * 100, 2)

    def _format_uptime(self, seconds: float) -> str:
        """Format uptime in human-readable format"""
        hours, remainder = divmod(int(seconds), 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def clear_all_queues(self) -> Dict:
        """
        Clear all queues and reset system
        
        Returns:
            Dictionary with counts of cleared items from each queue
        """
        priority_cleared = self.priority_queue.clear_all()
        batch_cleared = self.batch_queue.clear()
        retry_cleared = self.retry_queue.clear()
        
        # Reset system stats
        self.system_stats = {
            'total_messages_processed': 0,
            'successful_deliveries': 0,
            'failed_deliveries': 0,
            'messages_in_retry': 0,
            'system_uptime': time.time()
        }
        
        return {
            'priority_queue_cleared': priority_cleared,
            'batch_queue_cleared': batch_cleared,
            'retry_queue_cleared': retry_cleared,
            'system_reset': True
        }

    def shutdown(self):
        """Gracefully shutdown the enhanced message system"""
        print("Shutting down Enhanced Message System...")
        
        # Force send any pending batches
        pending_batch_count = self.force_send_pending_batches()
        if pending_batch_count > 0:
            print(f"Sent {pending_batch_count} pending messages before shutdown")
        
        # Stop retry queue worker
        self.retry_queue.stop()
        
        print("Enhanced Message System shutdown complete")

    def get_queue_status(self) -> Dict:
        """
        Get current status of all queues
        
        Returns:
            Dictionary with current queue sizes and states
        """
        return {
            'priority_queue_size': len(self.priority_queue.priority_queue),
            'batch_queue_size': self.batch_queue.current_batch_size(),
            'retry_queue_size': len(self.retry_queue.retry_queue),
            'history_size': len(self.priority_queue.history.get_all()),
            'batch_is_empty': self.batch_queue.is_empty(),
            'priority_is_empty': len(self.priority_queue.priority_queue) == 0,
            'system_health': 'healthy' if self._calculate_success_rate() > 80 else 'degraded'
        }